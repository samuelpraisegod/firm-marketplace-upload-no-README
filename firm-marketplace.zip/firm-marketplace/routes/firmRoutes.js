import { getFirms, getFirmNames, getPayoutDetails, getFirmDetails } from '../controllers/firmController.js';

export const fetchFirms = async (tab, firmName, favorite, sort) => {
  try {
    const data = await getFirms(tab, firmName, favorite, sort);
    if (!data) {
      console.error(`No data found for tab: ${tab}, firmName: ${firmName}`);
      return null;
    }
    return data;
  } catch (error) {
    console.error(`Error fetching firms for tab: ${tab}`, error);
    return null;
  }
};

export const fetchFirmNames = async () => {
  try {
    const data = await getFirmNames();
    if (!data) {
      console.error('No firm names found');
      return null;
    }
    return data;
  } catch (error) {
    console.error('Error fetching firm names:', error);
    return null;
  }
};

export const fetchPayoutDetails = async (firmId) => {
  try {
    const data = await getPayoutDetails(firmId);
    if (!data) {
      console.error(`No payout details found for firmId: ${firmId}`);
      return null;
    }
    return data;
  } catch (error) {
    console.error(`Error fetching payout details for firmId: ${firmId}`, error);
    return null;
  }
};

export const fetchFirmDetails = async (firmId, tab) => {
  try {
    const data = await getFirmDetails(firmId, tab);
    if (!data) {
      console.error(`No ${tab} data found for firmId: ${firmId}`);
      return null;
    }
    return data;
  } catch (error) {
    console.error(`Error fetching ${tab} details for firmId: ${firmId}`, error);
    return null;
  }
};