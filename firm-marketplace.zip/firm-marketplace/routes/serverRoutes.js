// routes/serverRoutes.js
import express from 'express';
import { getPayoutDetailsServer, getFirmDetailsServer } from '../controllers/firmController.js';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const router = express.Router();

router.get('/payouts', (req, res) => {
  res.sendFile(path.join(__dirname, '../pages/payouts.html'));
});

router.get('/challenges', (req, res) => {
  res.sendFile(path.join(__dirname, '../pages/challenges.html'));
});

router.get('/reviews', (req, res) => {
  res.sendFile(path.join(__dirname, '../pages/reviews.html'));
});

router.get('/offers', (req, res) => {
  res.sendFile(path.join(__dirname, '../pages/offers.html'));
});

router.get('/payout-details-:firmSlug-:firmId', (req, res) => {
  res.sendFile(path.join(__dirname, `../pages/payout-details-${req.params.firmSlug}-${req.params.firmId}.html`));
});

router.get('/firm-detail-:firmSlug-:firmId-:tab', (req, res) => {
  res.sendFile(path.join(__dirname, `../pages/firm-detail-${req.params.firmSlug}-${req.params.firmId}-${req.params.tab}.html`));
});

router.get('/payouts/:firmId', getPayoutDetailsServer);

router.get('/firms/:firmId/:tab', getFirmDetailsServer);

export default router;