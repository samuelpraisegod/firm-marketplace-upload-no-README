export const announcements = [
    { id: 1, firm_id: 1, title: "New Challenge Launched", content: "Introducing our new 2-step challenge!", created_at: "2025-09-15" },
    { id: 2, firm_id: 2, title: "Payout System Update", content: "Faster payouts starting October.", created_at: "2025-09-10" },
    { id: 3, firm_id: 3, title: "Webinar Announcement", content: "Join our trading webinar on Oct 5.", created_at: "2025-09-12" },
];

export const getAnnouncementsByFirmId = (firmId) => announcements.filter(ann => ann.firm_id === firmId);