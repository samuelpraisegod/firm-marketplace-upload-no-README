// components/table.js
import { fetchFirms } from '../routes/firmRoutes.js';

const tabConfigs = {
  payouts: {
    headers: ["Firm Name", "Rank", "Total Payouts ($)", "Number of Payouts", "Avg Payout Time (days)", "Avg Payout Amount ($)", "Last Payout", "Actions"],
    renderRow: (firm) => `
      <td><a href="../pages/payouts.html?firm=${firm.slug}">${firm.name}</a></td>
      <td>${firm.rank}</td>
      <td>${firm.payouts.reduce((sum, p) => sum + p.amount, 0).toLocaleString()}</td>
      <td>${firm.payouts.length}</td>
      <td>${(firm.payouts.reduce((sum, p) => sum + (new Date() - new Date(p.date)) / (1000 * 60 * 60 * 24), 0) / firm.payouts.length).toFixed(1)}</td>
      <td>${(firm.payouts.reduce((sum, p) => sum + p.amount, 0) / firm.payouts.length).toLocaleString()}</td>
      <td>${firm.payouts[0]?.date || 'N/A'}</td>
      <td><button class="action-btn" onclick="window.viewDetails(${firm.id}, 'payouts')">View Details</button></td>
    `
  },
  challenges: {
    headers: ["Firm Name", "Rank", "Number of Challenges", "Challenge Types", "Min Account Size ($)", "Profit Target (%)", "Max Drawdown (%)", "Actions"],
    renderRow: (firm) => `
      <td><a href="../pages/challenges.html?firm=${firm.slug}">${firm.name}</a></td>
      <td>${firm.rank}</td>
      <td>${firm.challenges.length}</td>
      <td>${[...new Set(firm.challenges.map(c => c.details.split(', ')[0]))].join(', ')}</td>
      <td>${Math.min(...firm.challenges.map(c => c.accountSize)).toLocaleString()}</td>
      <td>${Math.min(...firm.challenges.map(c => parseFloat(c.details.match(/(\d+)% profit/)[1])))}</td>
      <td>${Math.min(...firm.challenges.map(c => parseFloat(c.details.match(/(\d+)% daily/)[1])))}</td>
      <td><button class="action-btn" onclick="window.viewDetails(${firm.id}, 'challenges')">View Details</button></td>
    `
  },
  reviews: {
    headers: ["Firm Name", "Rank", "Average Rating", "Number of Reviews", "Trend", "Top Themes", "Actions"],
    renderRow: (firm) => `
      <td><a href="../pages/reviews.html?firm=${firm.slug}">${firm.name}</a></td>
      <td>${firm.rank}</td>
      <td>${(firm.reviews.reduce((sum, r) => sum + parseFloat(r.rating), 0) / firm.reviews.length).toFixed(1)}</td>
      <td>${firm.reviews.length}</td>
      <td>${firm.reviews[0]?.rating > firm.reviews[firm.reviews.length - 1]?.rating ? '↓' : '↑'}</td>
      <td>${firm.reviews.map(r => r.purchaseFeedback.slice(0, 20)).join(', ')}</td>
      <td><button class="action-btn" onclick="window.viewDetails(${firm.id}, 'reviews')">View Details</button></td>
    `
  },
  offers: {
    headers: ["Firm Name", "Rank", "Active Offers", "Offer Types", "Expiration Date", "Eligibility", "Actions"],
    renderRow: (firm) => `
      <td><a href="../pages/offers.html?firm=${firm.slug}">${firm.name}</a></td>
      <td>${firm.rank}</td>
      <td>${firm.offers.map(o => o.buyerBenefit).join(', ')}</td>
      <td>${firm.offers.map(o => o.offerName).join(', ')}</td>
      <td>${firm.offers[0]?.validity.split(' to ')[1] || firm.offers[0]?.validity}</td>
      <td>All Users</td>
      <td><button class="action-btn" onclick="window.viewDetails(${firm.id}, 'offers')">Claim Offer</button></td>
    `
  }
};

export async function renderTable(tabName) {
  const firmFilter = document.getElementById('firm-filter')?.value || 'all';
  const favoriteFilter = document.getElementById('favorite-filter')?.value || 'all';
  const sortType = document.querySelector('.sort-btn.active')?.dataset.sort || 'popular';
  const config = tabConfigs[tabName];

  const firms = await fetchFirms(tabName, firmFilter, favoriteFilter, sortType);

  const headerRow = config.headers.map(header => `<th>${header}</th>`).join('');
  document.getElementById('table-header').innerHTML = `<tr>${headerRow}</tr>`;

  const rows = firms.length ? firms.map(firm => `<tr>${config.renderRow(firm)}</tr>`).join('') :
    `<tr><td colspan="${config.headers.length}">No firms match the selected filters.</td></tr>`;
  document.getElementById('table-body').innerHTML = rows;
}

window.viewDetails = async function(firmId, tabName) {
  try {
    const { fetchFirmDetails } = await import('../routes/firmRoutes.js');
    const firm = await fetchFirmDetails(firmId, tabName);
    if (firm) {
      const firmSlug = firm.firmName.toLowerCase().replace(/\s+/g, '-');
      if (tabName === 'payouts') {
        window.location.href = `../pages/payout-details-${firmSlug}-${firmId}.html`;
      } else {
        window.location.href = `../pages/firm-detail-${firmSlug}-${firmId}-${tabName}.html`;
      }
    } else {
      console.error('Firm not found for ID:', firmId);
    }
  } catch (error) {
    console.error('Error in viewDetails:', error);
  }
};