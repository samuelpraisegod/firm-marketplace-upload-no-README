import { getFirmById, getFirmBySlug } from '../models/firm.js';
import { getReviewsByFirmId } from '../models/review.js';
import { getOffersByFirmId } from '../models/offer.js';
import { getAnnouncementsByFirmId } from '../models/announcement.js';
import { getPayoutsByFirmId } from '../models/payout.js';

export const getFirmDetails = async (identifier, isSlug = false) => {
    const firm = isSlug ? getFirmBySlug(identifier) : getFirmById(identifier);
    if (!firm) return null;

    const reviews = getReviewsByFirmId(firm.id);
    const offers = getOffersByFirmId(firm.id);
    const announcements = getAnnouncementsByFirmId(firm.id);
    const payouts = getPayoutsByFirmId(firm.id);

    // Calculate years in operation
    const dateCreated = new Date(firm.date_created);
    const yearsInOperation = Math.floor((new Date() - dateCreated) / (1000 * 60 * 60 * 24 * 365));

    // Ratings breakdown
    const ratingsBreakdown = [5, 4, 3, 2, 1, 0].map(stars => ({
        stars,
        count: reviews.filter(r => r.rating === stars).length,
    }));

    return {
        ...firm,
        yearsInOperation,
        ratingsBreakdown,
        reviews,
        offers,
        announcements,
        payouts,
    };
};