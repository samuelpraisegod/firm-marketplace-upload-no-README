// controllers/firmController.js
import { getFirmsByTab, getPayoutDetailsByFirmId, getFirmDetailsById } from '../models/firm.js';

export const getFirms = (tab, firmName, favorite, sort) => {
  let firms = [...getFirmsByTab(tab)];

  if (firmName !== 'all') {
    firms = firms.filter(firm => firm.name === firmName);
  }
  if (favorite !== 'all') {
    firms = firms.filter(firm => {
      const ratings = firm[tab].map(item => parseFloat(item.buyerRating || item.rating || '0'));
      const avgRating = ratings.length ? ratings.reduce((sum, r) => sum + r, 0) / ratings.length : 0;
      return Math.round(avgRating) === parseInt(favorite);
    });
  }
  if (sort === 'new') {
    firms = firms.filter(firm => firm[tab].some(item => new Date(item.date || item.validity.split(' to ')[0]) > new Date('2025-09-01')));
  }

  if (sort === 'popular') {
    firms.sort((a, b) => (b[tab].length || 0) - (a[tab].length || 0));
  } else if (sort === 'firm') {
    firms.sort((a, b) => a.name.localeCompare(b.name));
  } else {
    firms.sort((a, b) => {
      const aRating = a[tab].reduce((sum, item) => sum + parseFloat(item.buyerRating || item.rating || '0'), 0) / a[tab].length;
      const bRating = b[tab].reduce((sum, item) => sum + parseFloat(item.buyerRating || item.rating || '0'), 0) / b[tab].length;
      return bRating - aRating;
    });
  }

  return firms;
};

export const getFirmNames = () => {
  return import('../models/firm.js').then(module => module.getAllFirmNames());
};

export const getPayoutDetails = async (firmId) => {
  const data = getPayoutDetailsByFirmId(firmId);
  if (!data) {
    throw new Error('Firm not found');
  }
  return data;
};

export const getFirmDetails = async (firmId, tab) => {
  const data = getFirmDetailsById(firmId, tab);
  if (!data) {
    throw new Error('Firm not found');
  }
  return data;
};

export const getPayoutDetailsServer = async (req, res) => {
  try {
    const firmId = req.params.firmId;
    const data = getPayoutDetailsByFirmId(firmId);
    if (!data) {
      return res.status(404).json({ error: 'Firm not found' });
    }
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

export const getFirmDetailsServer = async (req, res) => {
  try {
    const { firmId, tab } = req.params;
    const data = getFirmDetailsById(firmId, tab);
    if (!data) {
      return res.status(404).json({ error: 'Firm not found' });
    }
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};