// components/tabs.js
import { renderTable } from './table.js';

document.addEventListener('DOMContentLoaded', () => {
  const tabsContainer = document.getElementById('tabs');
  if (!tabsContainer) return;

  const tabs = ['payouts', 'challenges', 'reviews', 'offers'];
  tabsContainer.innerHTML = tabs.map(tab => `
    <button class="tab ${tab === 'payouts' ? 'active' : ''}" data-tab="${tab}">
      ${tab.charAt(0).toUpperCase() + tab.slice(1)}
    </button>
  `).join('');

  tabsContainer.addEventListener('click', (e) => {
    if (e.target.classList.contains('tab')) {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      e.target.classList.add('active');
      renderTable(e.target.dataset.tab);
    }
  });

  renderTable('payouts');
});