// models/firm.js
const firms = {
  payouts: [
    {
      id: 1,
      name: "Funding Traders",
      slug: "funding-traders",
      payouts: [
        { payoutId: "PAY001", amount: 500, date: "2025-09-01", buyerFeedback: "Received in 2 days, smooth process", reliability: "5/5 (Fast)" },
        { payoutId: "PAY002", amount: 1200, date: "2025-09-15", buyerFeedback: "Pending, but support was helpful", reliability: "3/5 (Pending)" }
      ]
    },
    {
      id: 2,
      name: "FTMO",
      slug: "ftmo",
      payouts: [
        { payoutId: "PAY003", amount: 800, date: "2025-09-10", buyerFeedback: "Quick payout, great support", reliability: "4.5/5 (Fast)" },
        { payoutId: "PAY004", amount: 2000, date: "2025-09-20", buyerFeedback: "Smooth but fees high", reliability: "4/5 (Good)" }
      ]
    },
    {
      id: 3,
      name: "The5ers",
      slug: "the5ers",
      payouts: [
        { payoutId: "PAY005", amount: 600, date: "2025-09-05", buyerFeedback: "Reliable, processed in 3 days", reliability: "4.5/5 (Fast)" },
        { payoutId: "PAY006", amount: 1500, date: "2025-09-18", buyerFeedback: "Good but slow for bank transfer", reliability: "3.5/5 (Moderate)" }
      ]
    }
  ],
  challenges: [
    {
      id: 1,
      name: "Funding Traders",
      slug: "funding-traders",
      challenges: [
        { challengeId: "CH001", challengeName: "Starter Challenge", accountSize: 5000, cost: 100, buyerRating: "4.2/5", buyerFeedback: "Great for beginners, affordable", details: "2 phases, 10% profit, 5% daily/10% total drawdown, 30 days; Co-fund eligible (up to 2 partners)" },
        { challengeId: "CH002", challengeName: "Pro Trader", accountSize: 25000, cost: 250, buyerRating: "4.5/5", buyerFeedback: "Worth it for scaling", details: "2 phases, 12% profit, 5% daily/12% total drawdown, news trading OK; Co-fund eligible" },
        { challengeId: "CH003", challengeName: "Mini Challenge", accountSize: 2500, cost: 50, buyerRating: "4.0/5", buyerFeedback: "Perfect starter, low risk", details: "1 phase, 7% profit, 4% daily/7% total drawdown, demo first; Co-fund eligible" },
        { challengeId: "CH004", challengeName: "Supreme Trader", accountSize: 150000, cost: 600, buyerRating: "4.4/5", buyerFeedback: "Mentorship adds value", details: "2 phases, 9% profit, 5% daily/10% total drawdown, custom rules; Co-fund eligible" }
      ]
    },
    {
      id: 2,
      name: "FTMO",
      slug: "ftmo",
      challenges: [
        { challengeId: "CH005", challengeName: "Basic Eval", accountSize: 10000, cost: 150, buyerRating: "4.0/5", buyerFeedback: "Good value, rules are clear", details: "1 phase, 8% profit, 4% daily/8% total drawdown, unlimited time; Co-fund eligible (50/50 split)" },
        { challengeId: "CH006", challengeName: "Elite Funding", accountSize: 50000, cost: 400, buyerRating: "4.3/5", buyerFeedback: "High cost but great support", details: "2 phases, 10% profit, 6% daily/10% total drawdown, weekend holds; Co-fund eligible (custom splits)" },
        { challengeId: "CH007", challengeName: "Advanced Eval", accountSize: 200000, cost: 750, buyerRating: "4.6/5", buyerFeedback: "Best for pros, high reward", details: "3 phases, 15% profit, 5% daily/15% total drawdown, no martingale; Co-fund eligible" },
        { challengeId: "CH008", challengeName: "Flex Challenge", accountSize: 75000, cost: 350, buyerRating: "4.1/5", buyerFeedback: "Flexible rules, good for crypto", details: "2 phases, 8% profit, 4% daily/9% total drawdown, crypto OK; Co-fund eligible" }
      ]
    },
    {
      id: 3,
      name: "The5ers",
      slug: "the5ers",
      challenges: [
        { challengeId: "CH009", challengeName: "Rapid Challenge", accountSize: 100000, cost: 500, buyerRating: "3.8/5", buyerFeedback: "Tough but fast funding", details: "1 phase, 6% profit, 3% daily/6% total drawdown, 10-day deadline; Co-fund eligible" },
        { challengeId: "CH010", challengeName: "Ultimate Funding", accountSize: 300000, cost: 1000, buyerRating: "4.7/5", buyerFeedback: "Premium but worth it", details: "3 phases, 12% profit, 6% daily/12% total drawdown, instant funding; Co-fund eligible (up to 3 partners)" }
      ]
    }
  ],
  reviews: [
    {
      id: 1,
      name: "Funding Traders",
      slug: "funding-traders",
      reviews: [
        { reviewer: "TraderA", rating: "4.5/5", purchaseFeedback: "Worth the $100, passed in 20 days!", date: "2025-09-10", productReviewed: "Starter Challenge" },
        { reviewer: "UserB", rating: "3.0/5", purchaseFeedback: "Costly, but rules are fair", date: "2025-09-20", productReviewed: "Pro Trader" }
      ]
    },
    {
      id: 2,
      name: "FTMO",
      slug: "ftmo",
      reviews: [
        { reviewer: "TraderC", rating: "4.0/5", purchaseFeedback: "Clear process, passed in 15 days", date: "2025-09-12", productReviewed: "Basic Eval" },
        { reviewer: "UserD", rating: "4.5/5", purchaseFeedback: "Support was excellent", date: "2025-09-18", productReviewed: "Elite Funding" }
      ]
    },
    {
      id: 3,
      name: "The5ers",
      slug: "the5ers",
      reviews: [
        { reviewer: "TraderE", rating: "3.8/5", purchaseFeedback: "Fast funding but strict", date: "2025-09-15", productReviewed: "Rapid Challenge" },
        { reviewer: "UserF", rating: "4.2/5", purchaseFeedback: "Flexible and reliable", date: "2025-09-22", productReviewed: "Ultimate Funding" }
      ]
    }
  ],
  offers: [
    {
      id: 1,
      name: "Funding Traders",
      slug: "funding-traders",
      offers: [
        { offerId: "OFF001", offerName: "Welcome Bonus", description: "20% off first challenge fee", buyerBenefit: "Save $20-$200", validity: "2025-09-01 to 2025-12-31", buyerFeedback: "Great deal for new traders" },
        { offerId: "OFF002", offerName: "Referral Deal", description: "$100 credit per referral", buyerBenefit: "$100 bonus", validity: "Ongoing", buyerFeedback: "Easy to claim, worth it" }
      ]
    },
    {
      id: 2,
      name: "FTMO",
      slug: "ftmo",
      offers: [
        { offerId: "OFF003", offerName: "First-Time Discount", description: "15% off any challenge", buyerBenefit: "Save $15-$150", validity: "2025-09-01 to 2025-11-30", buyerFeedback: "Good value for new users" },
        { offerId: "OFF004", offerName: "Loyalty Bonus", description: "$50 credit on second purchase", buyerBenefit: "$50 bonus", validity: "Ongoing", buyerFeedback: "Nice perk for returning traders" }
      ]
    },
    {
      id: 3,
      name: "The5ers",
      slug: "the5ers",
      offers: [
        { offerId: "OFF005", offerName: "Early Bird Offer", description: "25% off challenges", buyerBenefit: "Save $25-$250", validity: "2025-09-01 to 2025-10-31", buyerFeedback: "Amazing discount, quick process" },
        { offerId: "OFF006", offerName: "Crypto Bonus", description: "Bonus for crypto payments", buyerBenefit: "$75 bonus", validity: "Ongoing", buyerFeedback: "Perfect for crypto traders" }
      ]
    }
  ]
};

export const getFirmsByTab = (tab) => firms[tab] || [];
export const getAllFirmNames = () => [...new Set(firms.payouts.map(firm => firm.name))];
export const getPayoutDetailsByFirmId = (firmId) => {
  const firm = firms.payouts.find(f => f.id === parseInt(firmId));
  return firm ? { firmName: firm.name, payouts: firm.payouts } : null;
};
export const getFirmDetailsById = (firmId, tab) => {
  const firm = firms[tab].find(f => f.id === parseInt(firmId));
  return firm ? { firmName: firm.name, [tab]: firm[tab] } : null;
};