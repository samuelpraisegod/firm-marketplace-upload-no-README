import { fetchFirmDetails } from '../routes/firmRoutes.js';

const detailTabConfigs = {
    overview: {
        render: (firm) => `
            <div class="overview">
                <p><strong>Category:</strong> ${firm.category}</p>
                <p><strong>Description:</strong> Lorem ipsum dolor sit amet, consectetur adipiscing elit. (Add real description later)</p>
            </div>
        `
    },
    challenges: {
        render: (firm) => `
            <table>
                <thead>
                    <tr>
                        <th>Challenge Type</th>
                        <th>Min Account Size ($)</th>
                        <th>Profit Target (%)</th>
                        <th>Max Drawdown (%)</th>
                    </tr>
                </thead>
                <tbody>
                    ${firm.challenges.map(c => `
                        <tr>
                            <td>${c.challengeTypes}</td>
                            <td>${c.minAccountSize.toLocaleString()}</td>
                            <td>${c.profitTarget}</td>
                            <td>${c.maxDrawdown}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `
    },
    reviews: {
        render: (firm) => `
            <div class="ratings-breakdown">
                <h3>Ratings Breakdown</h3>
                ${firm.ratingsBreakdown.map(r => `
                    <p>${r.stars}⭐: ${r.count} reviews</p>
                `).join('')}
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Rating</th>
                        <th>Comment</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    ${firm.reviews.map(r => `
                        <tr>
                            <td>${r.rating}⭐</td>
                            <td>${r.comment}</td>
                            <td>${r.created_at}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `
    },
    offers: {
        render: (firm) => `
            <table>
                <thead>
                    <tr>
                        <th>Discount</th>
                        <th>Code</th>
                        <th>Offer Type</th>
                        <th>Expiration</th>
                        <th>Eligibility</th>
                    </tr>
                </thead>
                <tbody>
                    ${firm.offers.map(o => `
                        <tr>
                            <td>${o.discount}</td>
                            <td>${o.code}</td>
                            <td>${o.offer_type}</td>
                            <td>${o.expiration}</td>
                            <td>${o.eligibility}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `
    },
    announcements: {
        render: (firm) => `
            <div class="announcements">
                ${firm.announcements.map(a => `
                    <div class="announcement">
                        <h3>${a.title}</h3>
                        <p>${a.content}</p>
                        <p><strong>Date:</strong> ${a.created_at}</p>
                    </div>
                `).join('')}
            </div>
        `
    },
    payouts: {
        render: (firm) => `
            <table>
                <thead>
                    <tr>
                        <th>Amount ($)</th>
                        <th>Payout Date</th>
                        <th>Payout Time (days)</th>
                    </tr>
                </thead>
                <tbody>
                    ${firm.payouts.map(p => `
                        <tr>
                            <td>${p.amount.toLocaleString()}</td>
                            <td>${p.payout_date}</td>
                            <td>${p.payout_time}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `
    }
};

document.addEventListener('DOMContentLoaded', async () => {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');
    const slug = params.get('slug');
    const identifier = slug || id;
    const isSlug = !!slug;

    const firm = await fetchFirmDetails(identifier, isSlug);
    if (!firm) {
        document.getElementById('firm-header').innerHTML = '<h2>Firm not found</h2>';
        return;
    }

    // Render firm header
    document.getElementById('firm-header').innerHTML = `
        <div class="firm-header">
            <img src="${firm.logo}" alt="${firm.name} logo" class="firm-logo">
            <h2>${firm.name}</h2>
            <p><img src="https://flagsapi.com/${firm.country}/flat/24.png" alt="${firm.country} flag"> ${firm.country}</p>
            <p><strong>TrustPilot Rating:</strong> ${firm.trustpilot_rating}⭐</p>
            <p><strong>Date Created:</strong> ${firm.date_created}</p>
            <p><strong>Years in Operation:</strong> ${firm.yearsInOperation}</p>
        </div>
    `;

    // Render tabs
    const tabs = ['overview', 'challenges', 'reviews', 'offers', 'announcements', 'payouts'];
    document.getElementById('detail-tabs').innerHTML = tabs.map(tab => `
        <button class="tab ${tab === 'overview' ? 'active' : ''}" data-tab="${tab}">
            ${tab.charAt(0).toUpperCase() + tab.slice(1)}
        </button>
    `).join('');

    // Render initial content
    renderTabContent('overview', firm);

    // Tab switching
    document.getElementById('detail-tabs').addEventListener('click', (e) => {
        if (e.target.classList.contains('tab')) {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            e.target.classList.add('active');
            renderTabContent(e.target.dataset.tab, firm);
        }
    });
});

function renderTabContent(tab, firm) {
    const config = detailTabConfigs[tab];
    document.getElementById('detail-content').innerHTML = config.render(firm);
}