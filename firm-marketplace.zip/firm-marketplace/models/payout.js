export const payouts = [
    { id: 1, firm_id: 1, amount: 10000, payout_date: "2025-09-18", payout_time: 14 },
    { id: 2, firm_id: 1, amount: 5000, payout_date: "2025-09-15", payout_time: 12 },
    { id: 3, firm_id: 2, amount: 7500, payout_date: "2025-09-17", payout_time: 10 },
    { id: 4, firm_id: 3, amount: 6000, payout_date: "2025-09-16", payout_time: 12 },
];

export const getPayoutsByFirmId = (firmId) => payouts.filter(payout => payout.firm_id === firmId);