export const reviews = [
    { id: 1, firm_id: 1, rating: 5, comment: "Great payouts!", created_at: "2025-09-10" },
    { id: 2, firm_id: 1, rating: 4, comment: "Good but high fees.", created_at: "2025-09-05" },
    { id: 3, firm_id: 2, rating: 5, comment: "Very reliable.", created_at: "2025-09-08" },
    { id: 4, firm_id: 2, rating: 3, comment: "Strict rules.", created_at: "2025-09-01" },
    { id: 5, firm_id: 3, rating: 4, comment: "Flexible challenges.", created_at: "2025-09-12" },
];

export const getReviewsByFirmId = (firmId) => reviews.filter(review => review.firm_id === firmId);