export const offers = [
    { id: 1, firm_id: 1, discount: "20% Off", code: "SAVE20", offer_type: "Bonus on Pass", expiration: "2025-10-31", eligibility: "All Users" },
    { id: 2, firm_id: 2, discount: "15% Off", code: "FTMO15", offer_type: "Free Retry", expiration: "2025-11-15", eligibility: "New Traders" },
    { id: 3, firm_id: 3, discount: "25% Off", code: "THE5ERS25", offer_type: "Bonus Capital", expiration: "2025-10-31", eligibility: "All Users" },
];

export const getOffersByFirmId = (firmId) => offers.filter(offer => offer.firm_id === firmId);