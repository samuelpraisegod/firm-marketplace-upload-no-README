// components/filters.js
import { fetchFirmNames } from '../routes/firmRoutes.js';
import { renderTable } from './table.js';

document.addEventListener('DOMContentLoaded', async () => {
  const filterSortContainer = document.getElementById('filter-sort');
  if (!filterSortContainer) return;

  filterSortContainer.innerHTML = `
    <div class="filter-group">
      <label for="firm-filter">Select Firm:</label>
      <select id="firm-filter"><option value="all">All Firms</option></select>
    </div>
    <div class="filter-group">
      <label for="favorite-filter">Favorite:</label>
      <select id="favorite-filter">
        <option value="all">All</option>
        <option value="0">0/5</option>
        <option value="1">1/5</option>
        <option value="2">2/5</option>
        <option value="3">3/5</option>
        <option value="4">4/5</option>
        <option value="5">5/5</option>
      </select>
    </div>
    <div class="sort-group">
      <button class="sort-btn active" data-sort="popular">Popular</button>
      <button class="sort-btn" data-sort="new">New</button>
      <button class="sort-btn" data-sort="all">All</button>
      <button class="sort-btn" data-sort="firm">Firm</button>
      <button class="sort-btn" data-sort="rank">Rank/Reviews</button>
    </div>
  `;

  const firmNames = await fetchFirmNames();
  const firmFilter = document.getElementById('firm-filter');
  firmFilter.innerHTML = '<option value="all">All Firms</option>' +
    firmNames.map(name => `<option value="${name}">${name}</option>`).join('');

  const updateTable = () => {
    const tab = document.querySelector('.tab.active')?.dataset.tab || 'payouts';
    renderTable(tab);
  };

  document.getElementById('firm-filter').addEventListener('change', updateTable);
  document.getElementById('favorite-filter').addEventListener('change', updateTable);
  document.querySelectorAll('.sort-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      updateTable();
    });
  });

  updateTable();
});